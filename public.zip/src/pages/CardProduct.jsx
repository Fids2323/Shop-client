import React from "react";

const CardProduct = () => {
	return <div>CardProduct</div>;
};

export default CardProduct;
