import React from "react";
import AddProducts from "./AddProducts";

const Dashboard = () => {
	return <AddProducts />;
};

export default Dashboard;
